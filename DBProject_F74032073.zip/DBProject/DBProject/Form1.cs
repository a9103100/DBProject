﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DBProject
{
    public partial class Form1 : Form
    {
        public MySqlConnection conn;

        public Form1()
        {
            InitializeComponent();
            //連接資料庫
            conn = new MySqlConnection("server=localhost;user=root;database=hospital;port=3306;password=a32299548A;");
            conn.Open();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Console.WriteLine(tabControl1.SelectedTab.Name);

            if (tabControl1.SelectedTab == tabPage2)   //科別
            {
                division_table.Rows.Clear();
                
                string sql = "SELECT * FROM division";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    //MySqlDataAdapter sda = new MySqlDataAdapter();

                    DataGridViewRowCollection rows = division_table.Rows;
                    
                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["DVNo"], data["DVName"], data["location"], data["DVNo"], "修改"});
                        //以欄位名稱取得資料並列出
                        //Console.WriteLine("id={0} , name={1}", data["DVNo"], data["DVName"]);
                    }
                }
                data.Close();

                //找到科別負責人
                for(int i = 0; i < division_table.RowCount; i++)
                {
                    //Console.WriteLine(division_table.Rows[i].Cells[3].Value); 
                    string sql_d = "SELECT doctor.name FROM division_doctor,division,doctor WHERE division_doctor.DSSN=doctor.DSSN AND division_doctor.DVNo=" + division_table.Rows[i].Cells[3].Value;
                    MySqlCommand cmd_d = new MySqlCommand(sql_d, conn);
                    string _name = (string)cmd_d.ExecuteScalar();
                    //Console.WriteLine(_name);
                    division_table.Rows[i].Cells[3].Value = _name;
                }
            }


            if (tabControl1.SelectedTab == tabPage3)   //醫生
            {
                doctor_table.Rows.Clear();
                string sql = "SELECT doctor.DSSN,sex,doctor.name,division.DVName FROM doctor_division,division,doctor WHERE division.DVNo=doctor_division.DVNo AND doctor_division.DSSN=doctor.DSSN";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    DataGridViewRowCollection rows = doctor_table.Rows;
                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["DSSN"], data["sex"], data["name"], data["DVName"], "修改" });
                    }
                }
                data.Close();
            }

            if (tabControl1.SelectedTab == tabPage4)   //病人
            {
                patient_table.Rows.Clear();
                string sql = "SELECT patient.PSSN,sex,PName FROM patient";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    DataGridViewRowCollection rows = patient_table.Rows;
                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["PSSN"], data["sex"], data["PName"], "修改" });
                    }
                }
                data.Close();
                //patient_table.Sort(patient_table.Columns[0], System.ComponentModel.ListSortDirection.Ascending);  //以病人身分証排序
            }

            if (tabControl1.SelectedTab == tabPage7)   //病歷
            {
                record_table.Rows.Clear();
                string sql = "SELECT record_patient_doctor.RNo,PName,date,time,doctor.name FROM patient,record,record_patient_doctor,doctor WHERE patient.PSSN=record_patient_doctor.PSSN AND record.RNo=record_patient_doctor.RNo AND doctor.DSSN=record_patient_doctor.DSSN";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    DataGridViewRowCollection rows = record_table.Rows;
                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["RNo"], data["PName"], data["date"], data["time"], data["name"], "刪除" });
                    }
                }
                data.Close();
                //patient_table.Sort(patient_table.Columns[0], System.ComponentModel.ListSortDirection.Ascending);  //以病人身分証排序
            }

            if (tabControl1.SelectedTab == tabPage5)   //醫療器材
            {
                equipment_table.Rows.Clear();
                string sql = "SELECT equipment.Eno,EName,price,DVName FROM equipment,equipment_division,division WHERE equipment.ENo=equipment_division.ENo AND equipment_division.DVNo=division.DVNo";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    DataGridViewRowCollection rows = equipment_table.Rows;
                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["ENo"], data["EName"], data["price"], data["DVName"], "刪除" });
                    }
                }
                data.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)   
        {
            //首頁的QUERY
            if(query_input.Text != "")
            {
                try
                {
                    string sql = query_input.Text;
                    MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
                    DataSet ds = new DataSet();
                    mda.Fill(ds, "result");
                    query_result.DataSource = ds.Tables["result"];
                }
                catch(Exception ex)
                {
                    MessageBox.Show("輸入有誤:"+ex.Message.ToString());
                }
            }
        }

        private void division_search_Click(object sender, EventArgs e)
        {
            //科別搜尋
            string search="";
            if(division_choose.SelectedIndex == 0) {search = "division.DVNo"; }
            else if(division_choose.SelectedIndex == 1) { search = "DVName"; }
            else if (division_choose.SelectedIndex == 2) { search = "location"; }
            else if (division_choose.SelectedIndex == 3){ search = "doctor.name"; }
            if (division_si.Text != "")
            {
                division_table.Rows.Clear();
                string sql = "SELECT division.DVNo,DVName,location,doctor.name FROM division_doctor,division,doctor WHERE division.DVNo=division_doctor.DVNo AND division_doctor.DSSN=doctor.DSSN AND " + search + "='" + division_si.Text + "'";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    //MySqlDataAdapter sda = new MySqlDataAdapter();

                    DataGridViewRowCollection rows = division_table.Rows;

                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["DVNo"], data["DVName"], data["location"], data["name"], "修改" });
                        //以欄位名稱取得資料並列出
                        //Console.WriteLine("id={0} , name={1}", data["DVNo"], data["DVName"]);
                    }
                }
                data.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //醫生搜尋
            string search = "";
            if (doctor_choose.SelectedIndex == 0) { search = "doctor.DSSN"; }
            else if (doctor_choose.SelectedIndex == 1) { search = "sex"; }
            else if (doctor_choose.SelectedIndex == 2) { search = "doctor.name"; }
            else if (doctor_choose.SelectedIndex == 3) { search = "division.DVName"; }
            if (doctor_si.Text != "")
            {
                doctor_table.Rows.Clear();
                string sql = "SELECT doctor.DSSN,sex,doctor.name,division.DVName FROM doctor_division,division,doctor WHERE division.DVNo=doctor_division.DVNo AND doctor_division.DSSN=doctor.DSSN AND " + search + "='" + doctor_si.Text + "'";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    DataGridViewRowCollection rows = doctor_table.Rows;
                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["DSSN"], data["sex"], data["name"], data["DVName"], "修改"});
                    }
                }
                data.Close();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //病人搜尋
            string search = "";
            if (patient_choose.SelectedIndex == 0) { search = "patient.PSSN"; }
            else if (patient_choose.SelectedIndex == 1) { search = "sex"; }
            else if (patient_choose.SelectedIndex == 2) { search = "PName"; }
            if (patient_si.Text != "")
            {
                patient_table.Rows.Clear();
                string sql = "SELECT patient.PSSN,sex,PName FROM patient WHERE " + search + "='" + patient_si.Text + "'";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    DataGridViewRowCollection rows = patient_table.Rows;
                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["PSSN"], data["sex"], data["PName"], "修改" });
                    }
                }
                data.Close();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //病歷搜尋
            string search = "";
            if (record_choose.SelectedIndex == 0) { search = "record_patient_doctor.RNo"; }
            else if (record_choose.SelectedIndex == 1) { search = "PName"; }
            else if (record_choose.SelectedIndex == 2) { search = "date"; }
            else if (record_choose.SelectedIndex == 3) { search = "doctor.name"; }
            if (record_si.Text != "")
            {
                record_table.Rows.Clear();
                string sql = "SELECT record_patient_doctor.RNo,PName,date,time,doctor.name FROM patient,record,record_patient_doctor,doctor WHERE patient.PSSN=record_patient_doctor.PSSN AND record.RNo=record_patient_doctor.RNo AND doctor.DSSN=record_patient_doctor.DSSN AND " + search + " ='" + record_si.Text + "'";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    DataGridViewRowCollection rows = record_table.Rows;
                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["RNo"], data["PName"], data["date"], data["time"], data["name"], "刪除" });
                    }
                }
                data.Close();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            //醫療設備查詢
            string search = ""; 
            if (equipment_choose.SelectedIndex == 0) { search = "equipment.Eno"; }
            else if (equipment_choose.SelectedIndex == 1) { search = "EName"; }
            else if (equipment_choose.SelectedIndex == 2) { search = "DVName"; }
            if (equipment_si.Text != "")
            {
                equipment_table.Rows.Clear();
                string sql = "SELECT equipment.Eno,EName,price,DVName FROM equipment,equipment_division,division WHERE equipment.ENo=equipment_division.ENo AND equipment_division.DVNo=division.DVNo AND " + search + " ='" + equipment_si.Text + "'";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader data = cmd.ExecuteReader();

                if (data.HasRows)   //如果有查到資料為 true 否則為 false
                {
                    DataGridViewRowCollection rows = equipment_table.Rows;
                    //列出查詢到的資料
                    while (data.Read())
                    {
                        rows.Add(new Object[] { data["ENo"], data["EName"], data["price"], data["DVName"], "刪除" });
                    }
                }
                data.Close();
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            //查詢醫師所屬科別的設備與其價錢
            if (doctor_n.Text != "")
            {
                string sql = "SELECT equipment.ENo,equipment.EName,price FROM equipment WHERE ENo IN (SELECT equipment_division.ENo FROM equipment_division,division,doctor_division,doctor WHERE equipment_division.DVNo=division.DVNo AND doctor_division.DVNo=division.DVNo AND doctor_division.DSSN=doctor.DSSN AND doctor.name = '" + doctor_n.Text + "')";
                MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                mda.Fill(ds, "result");
                if (ds != null && ds.Tables[0].Rows.Count > 0)
                    search_result.DataSource = ds.Tables["result"];
                else
                    MessageBox.Show("查無資料!");
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            //查詢沒有醫療儀器的科別
            string sql = "SELECT division.DVNo,DVName FROM division WHERE DVNo NOT IN (SELECT equipment_division.DVNo FROM equipment_division)";
            MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            mda.Fill(ds, "result");
            search_result.DataSource = ds.Tables["result"];
        }

        private void button20_Click(object sender, EventArgs e)
        {
            //查詢有醫療儀器的科別
            string sql = "SELECT division.DVNo,DVName FROM division WHERE EXISTS (SELECT * FROM equipment_division WHERE division.DVNo=equipment_division.DVNo)";
            MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            mda.Fill(ds, "result");
            search_result.DataSource = ds.Tables["result"];
        }

        private void button18_Click(object sender, EventArgs e)
        {
            //查詢沒有管理科別的醫生
            string sql = "SELECT doctor.DSSN,doctor.sex,name FROM doctor WHERE NOT EXISTS (SELECT * FROM division_doctor WHERE doctor.DSSN=division_doctor.DSSN)";
            MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            mda.Fill(ds, "result");
            search_result.DataSource = ds.Tables["result"];
        }

        private void button11_Click(object sender, EventArgs e)
        {
            //查詢每位病患看診次數
            string sql = "SELECT COUNT(*),PName FROM record_patient_doctor,patient WHERE record_patient_doctor.PSSN=patient.PSSN GROUP BY PName";
            MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            mda.Fill(ds, "result");
            search_result.DataSource = ds.Tables["result"];
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //查詢各科別擁有的設備價錢總金額
            string sql = "SELECT SUM(price),DVName FROM equipment,equipment_division,division WHERE equipment.ENo=equipment_division.Eno AND equipment_division.DVNo=division.DVNo GROUP BY DVName";
            MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            mda.Fill(ds, "result");
            search_result.DataSource = ds.Tables["result"];
        }

        private void button16_Click(object sender, EventArgs e)
        {
            //查詢平均一位病患來醫院的次數
            string sql = "SELECT AVG(mycount) FROM (SELECT COUNT(*) mycount FROM record_patient_doctor GROUP BY PSSN) AS count";
            MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            mda.Fill(ds, "result");
            search_result.DataSource = ds.Tables["result"];
        }

        private void button17_Click(object sender, EventArgs e)
        {
            //查詢擁有超過?個病人的醫生
            if (how_many.Text != "")
            {
                string sql = "SELECT name, sex, doctor.DSSN,COUNT(*) FROM doctor, record_patient_doctor WHERE doctor.DSSN = record_patient_doctor.DSSN GROUP BY name,DSSN HAVING COUNT(*) > " + how_many.Text;
                MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                mda.Fill(ds, "result");
                if (ds != null && ds.Tables[0].Rows.Count > 0)
                    search_result.DataSource = ds.Tables["result"];
                else
                    MessageBox.Show("查無資料!");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //查詢最貴的設備
            string sql = "SELECT EName,price,DVName FROM equipment,equipment_division,division WHERE equipment.ENo=equipment_division.Eno AND equipment_division.DVNo=division.DVNo AND price=(SELECT MAX(price) FROM equipment)";
            MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            mda.Fill(ds, "result");
            search_result.DataSource = ds.Tables["result"];
        }

        private void button13_Click(object sender, EventArgs e)
        {
            //查詢最便宜的設備
            string sql = "SELECT EName,price,DVName FROM equipment,equipment_division,division WHERE equipment.ENo=equipment_division.Eno AND equipment_division.DVNo=division.DVNo AND price=(SELECT MIN(price) FROM equipment)";
            MySqlDataAdapter mda = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            mda.Fill(ds, "result");
            search_result.DataSource = ds.Tables["result"];
        }



        private void doctor_table_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //醫生修改/刪除
            if (e.ColumnIndex == 4)  //修改
            {
                Form3 f = new Form3(doctor_table.Rows[e.RowIndex].Cells[0].Value.ToString(), doctor_table.Rows[e.RowIndex].Cells[1].Value.ToString(), doctor_table.Rows[e.RowIndex].Cells[2].Value.ToString(), doctor_table.Rows[e.RowIndex].Cells[3].Value.ToString());
                f.ShowDialog(this);
                if (f.DialogResult == System.Windows.Forms.DialogResult.OK)
                {
                    
                    //MessageBox.Show("修改成功");
                    doctor_table.Rows.Clear();
                    string sql3 = "SELECT doctor.DSSN,sex,doctor.name,division.DVName FROM doctor_division,division,doctor WHERE division.DVNo=doctor_division.DVNo AND doctor_division.DSSN=doctor.DSSN";
                    MySqlCommand cmd3 = new MySqlCommand(sql3, conn);
                    MySqlDataReader data = cmd3.ExecuteReader();

                    if (data.HasRows)   //如果有查到資料為 true 否則為 false
                    {
                        DataGridViewRowCollection rows = doctor_table.Rows;
                        //列出查詢到的資料
                        while (data.Read())
                        {
                            rows.Add(new Object[] { data["DSSN"], data["sex"], data["name"], data["DVName"], "修改", "刪除" });
                        }
                    }
                    data.Close();
                }
            }
    
        }

        private void division_table_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //科別修改
            if (e.ColumnIndex == 4)  //修改
            {
                //MessageBox.Show(division_table.Rows[e.RowIndex].Cells[0].Value.ToString());
                Form2 f = new Form2(division_table.Rows[e.RowIndex].Cells[0].Value.ToString(),division_table.Rows[e.RowIndex].Cells[1].Value.ToString(), division_table.Rows[e.RowIndex].Cells[2].Value.ToString(), division_table.Rows[e.RowIndex].Cells[3].Value.ToString());
                f.ShowDialog(this);
                if (f.DialogResult == System.Windows.Forms.DialogResult.OK)
                {
                    //若使用者在Form2按下了OK，則進入這個判斷式
                    //MessageBox.Show("修改成功");
                    division_table.Rows.Clear();
                    string sql = "SELECT division.DVNo,DVName,location,name FROM division,division_doctor,doctor WHERE division.DVNo=division_doctor.DVNo AND division_doctor.DSSN=doctor.DSSN";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    MySqlDataReader data = cmd.ExecuteReader();

                    if (data.HasRows)   //如果有查到資料為 true 否則為 false
                    {
                        DataGridViewRowCollection rows = division_table.Rows;
                        //列出查詢到的資料
                        while (data.Read())
                        {
                            rows.Add(new Object[] { data["DVNo"], data["DVName"], data["location"], data["name"], "修改" });
                        }
                    }
                    data.Close();
                }
            }
        }

        private void patient_table_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //病患修改
            if (e.ColumnIndex == 3)  //修改
            {
                //MessageBox.Show(division_table.Rows[e.RowIndex].Cells[0].Value.ToString());
                Form4 f = new Form4(patient_table.Rows[e.RowIndex].Cells[0].Value.ToString(), patient_table.Rows[e.RowIndex].Cells[1].Value.ToString(), patient_table.Rows[e.RowIndex].Cells[2].Value.ToString());
                f.ShowDialog(this);
                if (f.DialogResult == System.Windows.Forms.DialogResult.OK)
                {
                    //若使用者在Form2按下了OK，則進入這個判斷式
                    //MessageBox.Show("修改成功");
                    patient_table.Rows.Clear();
                    string sql = "SELECT patient.PSSN,sex,PName FROM patient";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    MySqlDataReader data = cmd.ExecuteReader();

                    if (data.HasRows)   //如果有查到資料為 true 否則為 false
                    {
                        DataGridViewRowCollection rows = patient_table.Rows;
                        //列出查詢到的資料
                        while (data.Read())
                        {
                            rows.Add(new Object[] { data["PSSN"], data["sex"], data["PName"], "修改" });
                        }
                    }
                    data.Close();
                }
            }
        }

        private void record_table_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 5)  //病歷刪除
            {
                String content = "病歷編號：" + record_table.Rows[e.RowIndex].Cells[0].Value.ToString()
                                 + "\n病患名字：" + record_table.Rows[e.RowIndex].Cells[1].Value.ToString()
                                 + "\n日期：" + record_table.Rows[e.RowIndex].Cells[2].Value.ToString()
                                 + "\n時間：" + record_table.Rows[e.RowIndex].Cells[3].Value.ToString()
                                 + "\n醫師姓名：" + record_table.Rows[e.RowIndex].Cells[4].Value.ToString();


                DialogResult result = MessageBox.Show("確定刪除此資料嗎?\n\n" + content, "刪除", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (result == DialogResult.OK)
                {
                    string sql = "DELETE FROM record WHERE RNo='" + record_table.Rows[e.RowIndex].Cells[0].Value.ToString() + "'";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    string sql2 = "DELETE FROM record_patient_doctor WHERE RNo='" + record_table.Rows[e.RowIndex].Cells[0].Value.ToString() + "'";
                    MySqlCommand cmd2 = new MySqlCommand(sql2, conn);
                    cmd2.ExecuteNonQuery();
                    MessageBox.Show("刪除成功");

                    record_table.Rows.Clear();
                    string sql3 = "SELECT record_patient_doctor.RNo,PName,date,time,doctor.name FROM patient,record,record_patient_doctor,doctor WHERE patient.PSSN=record_patient_doctor.PSSN AND record.RNo=record_patient_doctor.RNo AND doctor.DSSN=record_patient_doctor.DSSN";
                    MySqlCommand cmd3 = new MySqlCommand(sql3, conn);
                    MySqlDataReader data = cmd3.ExecuteReader();

                    if (data.HasRows)   //如果有查到資料為 true 否則為 false
                    {
                        DataGridViewRowCollection rows = record_table.Rows;
                        //列出查詢到的資料
                        while (data.Read())
                        {
                            rows.Add(new Object[] { data["RNo"], data["PName"], data["date"], data["time"], data["name"], "刪除" });
                        }
                    }
                    data.Close();
                }
            }
        }

        private void equipment_table_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 4)  //器材刪除
            {
                String content = "器材編號：" + equipment_table.Rows[e.RowIndex].Cells[0].Value.ToString()
                                 + "\n器材名字：" + equipment_table.Rows[e.RowIndex].Cells[1].Value.ToString()
                                 + "\n價錢：" + equipment_table.Rows[e.RowIndex].Cells[2].Value.ToString()
                                 + "\n所屬科別：" + equipment_table.Rows[e.RowIndex].Cells[3].Value.ToString();
                                
               
                DialogResult result = MessageBox.Show("確定刪除此資料嗎?\n\n" + content, "刪除", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (result == DialogResult.OK)
                {
                    string sql = "DELETE FROM equipment WHERE ENo='" + equipment_table.Rows[e.RowIndex].Cells[0].Value.ToString() + "'";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();
                    string sql2 = "DELETE FROM equipment_division WHERE ENo='" + equipment_table.Rows[e.RowIndex].Cells[0].Value.ToString() + "'";
                    MySqlCommand cmd2 = new MySqlCommand(sql2, conn);
                    cmd2.ExecuteNonQuery();
                    MessageBox.Show("刪除成功");

                    equipment_table.Rows.Clear();
                    string sql3 = "SELECT equipment.Eno,EName,price,DVName FROM equipment,equipment_division,division WHERE equipment.ENo=equipment_division.ENo AND equipment_division.DVNo=division.DVNo";
                    MySqlCommand cmd3 = new MySqlCommand(sql3, conn);
                    MySqlDataReader data = cmd3.ExecuteReader();

                    if (data.HasRows)   //如果有查到資料為 true 否則為 false
                    {
                        DataGridViewRowCollection rows = equipment_table.Rows;
                        //列出查詢到的資料
                        while (data.Read())
                        {
                            rows.Add(new Object[] { data["ENo"], data["EName"], data["price"], data["DVName"], "刪除" });
                        }
                    }
                    data.Close();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //新增醫師
            if (d_name.Text == "" || d_SSN.Text == "" || d_sex.Text == "" || d_dvname.Text=="")
            {
                MessageBox.Show("欄位不得為空");
            }
            else
            {
                string sql2 = "SELECT DVNo FROM division WHERE DVName='" + d_dvname.Text + "'";
                MySqlCommand cmd2 = new MySqlCommand(sql2, conn);
                string _DVNo = "";
                int num=0;
                if (cmd2.ExecuteScalar() == null)  //找不到資料
                {
                    _DVNo = (String)cmd2.ExecuteScalar();
                }
                else  //找出科別編號
                {
                    num = (int)cmd2.ExecuteScalar();
                }

                if (_DVNo == null)
                {
                    MessageBox.Show("無此科別");
                }
                else
                {
                    try {
                        string sql = "INSERT INTO doctor (DSSN,sex,name) VALUES ('" + d_SSN.Text + "','" + d_sex.Text + "','" + d_name.Text + "')";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        cmd.ExecuteNonQuery();

                        string sql3 = "INSERT INTO doctor_division (DSSN,DVNo) VALUES('" + d_SSN.Text + "'," + num + ")";
                        MySqlCommand cmd3 = new MySqlCommand(sql3, conn);
                        cmd3.ExecuteNonQuery();

                        MessageBox.Show("新增成功");

                        doctor_table.Rows.Clear();
                        string sql4 = "SELECT doctor.DSSN,sex,doctor.name,division.DVName FROM doctor_division,division,doctor WHERE division.DVNo=doctor_division.DVNo AND doctor_division.DSSN=doctor.DSSN";
                        MySqlCommand cmd4 = new MySqlCommand(sql4, conn);
                        MySqlDataReader data = cmd4.ExecuteReader();

                        if (data.HasRows)   //如果有查到資料為 true 否則為 false
                        {
                            DataGridViewRowCollection rows = doctor_table.Rows;
                            //列出查詢到的資料
                            while (data.Read())
                            {
                                rows.Add(new Object[] { data["DSSN"], data["sex"], data["name"], data["DVName"], "修改", "刪除" });
                            }
                        }
                        data.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("輸入有誤:" + ex.Message.ToString());
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //新增病人
            if (p_name.Text == "" || p_SSN.Text == "" || p_sex.Text == "")
            {
                MessageBox.Show("欄位不得為空");
            }
            else
            {
                try
                {
                    string sql = "INSERT INTO patient (PSSN,sex,PName) VALUES ('" + p_SSN.Text + "','" + p_sex.Text + "','" + p_name.Text + "')";
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("新增成功");
                    patient_table.Rows.Clear();
                    string sql2 = "SELECT patient.PSSN,sex,PName FROM patient";
                    MySqlCommand cmd2 = new MySqlCommand(sql2, conn);
                    MySqlDataReader data = cmd2.ExecuteReader();

                    if (data.HasRows)   //如果有查到資料為 true 否則為 false
                    {
                        DataGridViewRowCollection rows = patient_table.Rows;
                        //列出查詢到的資料
                        while (data.Read())
                        {
                            rows.Add(new Object[] { data["PSSN"], data["sex"], data["PName"], "修改" });
                        }
                    }
                    data.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("輸入有誤:" + ex.Message.ToString());
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //新增儀器
            if (e_name.Text == "" || e_dvno.Text == "" || e_price.Text == "")
            {
                MessageBox.Show("欄位不得為空");
            }
            else
            {
                string sql2 = "SELECT DVNo FROM division WHERE DVName='" + e_dvno.Text + "'";
                MySqlCommand cmd2 = new MySqlCommand(sql2, conn);
                string _DVNo = "";
                int num = 0;
                if (cmd2.ExecuteScalar() == null)  //找不到資料
                {
                    _DVNo = (String)cmd2.ExecuteScalar();
                }
                else  //找出科別編號
                {
                    num = (int)cmd2.ExecuteScalar();
                }

                if (_DVNo == null)
                {
                    MessageBox.Show("無此科別");
                }
                else
                {
                    try
                    {
                        string sql = "INSERT INTO equipment (EName,price) VALUES ('" + e_name.Text + "','" + e_price.Text + "')";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        cmd.ExecuteNonQuery();

                        string sql5 = "SELECT ENo FROM equipment WHERE EName='" + e_name.Text + "' AND price="+ e_price.Text;
                        MySqlCommand cmd5 = new MySqlCommand(sql5, conn);
                        int eno = (int)cmd5.ExecuteScalar();

                        string sql3 = "INSERT INTO equipment_division (ENo,DVNo) VALUES('" + eno + "'," + num + ")";
                        MySqlCommand cmd3 = new MySqlCommand(sql3, conn);
                        cmd3.ExecuteNonQuery();

                        MessageBox.Show("新增成功");
                        equipment_table.Rows.Clear();
                        string sql4 = "SELECT equipment.Eno,EName,price,DVName FROM equipment,equipment_division,division WHERE equipment.ENo=equipment_division.ENo AND equipment_division.DVNo=division.DVNo";
                        MySqlCommand cmd4 = new MySqlCommand(sql4, conn);
                        MySqlDataReader data = cmd4.ExecuteReader();

                        if (data.HasRows)   //如果有查到資料為 true 否則為 false
                        {
                            DataGridViewRowCollection rows = equipment_table.Rows;
                            //列出查詢到的資料
                            while (data.Read())
                            {
                                rows.Add(new Object[] { data["ENo"], data["EName"], data["price"], data["DVName"], "刪除" });
                            }
                        }
                        data.Close();

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("輸入有誤:" + ex.Message.ToString());
                    }
                }
            }
        }
    }
}
