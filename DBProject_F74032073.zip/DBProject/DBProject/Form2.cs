﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProject
{
    public partial class Form2 : Form
    {
        public String num;

        //科別修改
        public Form2(String dvno,String name,String location,String r)
        {
            InitializeComponent();

            button2.DialogResult = System.Windows.Forms.DialogResult.OK;//設定button1為OK
            button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;//設定button為Cancel

            textBox1.Text = name;
            textBox2.Text = location;
            textBox3.Text = r;
            num = dvno;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("欄位不得為空");
            }
            else
            {
                Form1 f1 = new Form1();
                string sql = "UPDATE division SET DVName='" + textBox1.Text + "',location='" + textBox2.Text + "' WHERE DVNo=" + num;
                MySqlCommand cmd = new MySqlCommand(sql, f1.conn);
                cmd.ExecuteNonQuery();

                string sql2 = "SELECT DSSN FROM doctor WHERE name='" + textBox3.Text + "'";
                MySqlCommand cmd2 = new MySqlCommand(sql2, f1.conn);
                string _SSN = (string)cmd2.ExecuteScalar();
                
                if (_SSN==null)
                {
                    MessageBox.Show("無此醫生資料");
                }
                else
                {
                    string sql3 = "UPDATE division_doctor SET DSSN='" + _SSN + "' WHERE DVNo=" + num;
                    MySqlCommand cmd3 = new MySqlCommand(sql3, f1.conn);
                    cmd3.ExecuteNonQuery();
                }
            }
        }
    }
}
