﻿namespace DBProject
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.e_dvno = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.e_name = new System.Windows.Forms.TextBox();
            this.e_price = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.equipment_choose = new System.Windows.Forms.ComboBox();
            this.equipment_si = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.equipment_table = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.record_table = new System.Windows.Forms.DataGridView();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.record_choose = new System.Windows.Forms.ComboBox();
            this.record_si = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.patient_table = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.patient_choose = new System.Windows.Forms.ComboBox();
            this.patient_si = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.p_sex = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.p_sex1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.p_name = new System.Windows.Forms.TextBox();
            this.p_SSN = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.doctor_table = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.d_dvname = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.d_sex = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.d_name = new System.Windows.Forms.TextBox();
            this.d_SSN = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.doctor_choose = new System.Windows.Forms.ComboBox();
            this.doctor_si = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.division_choose = new System.Windows.Forms.ComboBox();
            this.division_si = new System.Windows.Forms.TextBox();
            this.division_search = new System.Windows.Forms.Button();
            this.division_table = new System.Windows.Forms.DataGridView();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.query_result = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.query_input = new System.Windows.Forms.RichTextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.doctor_n = new System.Windows.Forms.TextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.how_many = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button13 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.search_result = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn3 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn6 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn8 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tabPage5.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.equipment_table)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.record_table)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.patient_table)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.doctor_table)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.division_table)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.query_result)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.search_result)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox10);
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Controls.Add(this.equipment_table);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1107, 592);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "醫療器材";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label13);
            this.groupBox10.Controls.Add(this.label17);
            this.groupBox10.Controls.Add(this.button10);
            this.groupBox10.Controls.Add(this.e_dvno);
            this.groupBox10.Controls.Add(this.label18);
            this.groupBox10.Controls.Add(this.label20);
            this.groupBox10.Controls.Add(this.e_name);
            this.groupBox10.Controls.Add(this.e_price);
            this.groupBox10.Location = new System.Drawing.Point(21, 23);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(1069, 78);
            this.groupBox10.TabIndex = 16;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "新增醫療器材";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(546, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 24);
            this.label13.TabIndex = 8;
            this.label13.Text = "科別：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label17.Location = new System.Drawing.Point(306, 60);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 24);
            this.label17.TabIndex = 7;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(951, 26);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(92, 34);
            this.button10.TabIndex = 0;
            this.button10.Text = "新增";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // e_dvno
            // 
            this.e_dvno.Location = new System.Drawing.Point(634, 26);
            this.e_dvno.Name = "e_dvno";
            this.e_dvno.Size = new System.Drawing.Size(227, 25);
            this.e_dvno.TabIndex = 6;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.Location = new System.Drawing.Point(306, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 24);
            this.label18.TabIndex = 5;
            this.label18.Text = "價錢：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label20.Location = new System.Drawing.Point(18, 26);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(130, 24);
            this.label20.TabIndex = 3;
            this.label20.Text = "設備名稱：";
            // 
            // e_name
            // 
            this.e_name.Location = new System.Drawing.Point(160, 26);
            this.e_name.Name = "e_name";
            this.e_name.Size = new System.Drawing.Size(127, 25);
            this.e_name.TabIndex = 1;
            // 
            // e_price
            // 
            this.e_price.Location = new System.Drawing.Point(394, 26);
            this.e_price.Name = "e_price";
            this.e_price.Size = new System.Drawing.Size(115, 25);
            this.e_price.TabIndex = 2;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.equipment_choose);
            this.groupBox9.Controls.Add(this.equipment_si);
            this.groupBox9.Controls.Add(this.button9);
            this.groupBox9.Location = new System.Drawing.Point(21, 120);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(1069, 100);
            this.groupBox9.TabIndex = 15;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "查詢設備資料";
            // 
            // equipment_choose
            // 
            this.equipment_choose.FormattingEnabled = true;
            this.equipment_choose.Items.AddRange(new object[] {
            "器材編號",
            "器材名稱",
            "所屬科別"});
            this.equipment_choose.Location = new System.Drawing.Point(22, 43);
            this.equipment_choose.Name = "equipment_choose";
            this.equipment_choose.Size = new System.Drawing.Size(121, 23);
            this.equipment_choose.TabIndex = 2;
            this.equipment_choose.Text = "請選擇";
            // 
            // equipment_si
            // 
            this.equipment_si.Location = new System.Drawing.Point(160, 41);
            this.equipment_si.Name = "equipment_si";
            this.equipment_si.Size = new System.Drawing.Size(784, 25);
            this.equipment_si.TabIndex = 1;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(971, 41);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(92, 32);
            this.button9.TabIndex = 0;
            this.button9.Text = "查詢";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // equipment_table
            // 
            this.equipment_table.AllowUserToAddRows = false;
            this.equipment_table.AllowUserToDeleteRows = false;
            this.equipment_table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.equipment_table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewButtonColumn8});
            this.equipment_table.Location = new System.Drawing.Point(21, 241);
            this.equipment_table.Name = "equipment_table";
            this.equipment_table.ReadOnly = true;
            this.equipment_table.RowHeadersVisible = false;
            this.equipment_table.RowTemplate.Height = 27;
            this.equipment_table.Size = new System.Drawing.Size(1069, 321);
            this.equipment_table.TabIndex = 14;
            this.equipment_table.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.equipment_table_CellClick);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.record_table);
            this.tabPage7.Controls.Add(this.groupBox8);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1107, 592);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "病歷";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // record_table
            // 
            this.record_table.AllowUserToAddRows = false;
            this.record_table.AllowUserToDeleteRows = false;
            this.record_table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.record_table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn12,
            this.Column7,
            this.dataGridViewButtonColumn6});
            this.record_table.Location = new System.Drawing.Point(21, 154);
            this.record_table.Name = "record_table";
            this.record_table.ReadOnly = true;
            this.record_table.RowHeadersVisible = false;
            this.record_table.RowTemplate.Height = 27;
            this.record_table.Size = new System.Drawing.Size(1069, 414);
            this.record_table.TabIndex = 14;
            this.record_table.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.record_table_CellClick);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.record_choose);
            this.groupBox8.Controls.Add(this.record_si);
            this.groupBox8.Controls.Add(this.button8);
            this.groupBox8.Location = new System.Drawing.Point(21, 28);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1069, 100);
            this.groupBox8.TabIndex = 13;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "查詢病歷";
            // 
            // record_choose
            // 
            this.record_choose.FormattingEnabled = true;
            this.record_choose.Items.AddRange(new object[] {
            "病歷編號",
            "病患名字",
            "日期",
            "醫師姓名"});
            this.record_choose.Location = new System.Drawing.Point(22, 43);
            this.record_choose.Name = "record_choose";
            this.record_choose.Size = new System.Drawing.Size(121, 23);
            this.record_choose.TabIndex = 2;
            this.record_choose.Text = "請選擇";
            // 
            // record_si
            // 
            this.record_si.Location = new System.Drawing.Point(160, 41);
            this.record_si.Name = "record_si";
            this.record_si.Size = new System.Drawing.Size(784, 25);
            this.record_si.TabIndex = 1;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(971, 41);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(92, 32);
            this.button8.TabIndex = 0;
            this.button8.Text = "查詢";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.patient_table);
            this.tabPage4.Controls.Add(this.groupBox6);
            this.tabPage4.Controls.Add(this.groupBox5);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1107, 592);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "病患";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // patient_table
            // 
            this.patient_table.AllowUserToAddRows = false;
            this.patient_table.AllowUserToDeleteRows = false;
            this.patient_table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.patient_table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewButtonColumn3});
            this.patient_table.Location = new System.Drawing.Point(21, 266);
            this.patient_table.Name = "patient_table";
            this.patient_table.ReadOnly = true;
            this.patient_table.RowHeadersVisible = false;
            this.patient_table.RowTemplate.Height = 27;
            this.patient_table.Size = new System.Drawing.Size(1069, 301);
            this.patient_table.TabIndex = 13;
            this.patient_table.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.patient_table_CellClick);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.patient_choose);
            this.groupBox6.Controls.Add(this.patient_si);
            this.groupBox6.Controls.Add(this.button6);
            this.groupBox6.Location = new System.Drawing.Point(21, 137);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1069, 100);
            this.groupBox6.TabIndex = 12;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "查詢病患資料";
            // 
            // patient_choose
            // 
            this.patient_choose.FormattingEnabled = true;
            this.patient_choose.Items.AddRange(new object[] {
            "身分證字號",
            "性別",
            "病患名字"});
            this.patient_choose.Location = new System.Drawing.Point(22, 43);
            this.patient_choose.Name = "patient_choose";
            this.patient_choose.Size = new System.Drawing.Size(121, 23);
            this.patient_choose.TabIndex = 2;
            this.patient_choose.Text = "請選擇";
            // 
            // patient_si
            // 
            this.patient_si.Location = new System.Drawing.Point(160, 41);
            this.patient_si.Name = "patient_si";
            this.patient_si.Size = new System.Drawing.Size(784, 25);
            this.patient_si.TabIndex = 1;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(971, 41);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(92, 32);
            this.button6.TabIndex = 0;
            this.button6.Text = "查詢";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button5);
            this.groupBox5.Controls.Add(this.p_sex);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.p_sex1);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.p_name);
            this.groupBox5.Controls.Add(this.p_SSN);
            this.groupBox5.Location = new System.Drawing.Point(21, 23);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1069, 95);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "新增病患資料";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(971, 26);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(92, 34);
            this.button5.TabIndex = 0;
            this.button5.Text = "新增";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // p_sex
            // 
            this.p_sex.Location = new System.Drawing.Point(103, 59);
            this.p_sex.Name = "p_sex";
            this.p_sex.Size = new System.Drawing.Size(40, 25);
            this.p_sex.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(306, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(154, 24);
            this.label10.TabIndex = 5;
            this.label10.Text = "身分證字號：";
            // 
            // p_sex1
            // 
            this.p_sex1.AutoSize = true;
            this.p_sex1.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.p_sex1.Location = new System.Drawing.Point(18, 59);
            this.p_sex1.Name = "p_sex1";
            this.p_sex1.Size = new System.Drawing.Size(82, 24);
            this.p_sex1.TabIndex = 4;
            this.p_sex1.Text = "性別：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(18, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(130, 24);
            this.label12.TabIndex = 3;
            this.label12.Text = "病人名字：";
            // 
            // p_name
            // 
            this.p_name.Location = new System.Drawing.Point(160, 26);
            this.p_name.Name = "p_name";
            this.p_name.Size = new System.Drawing.Size(127, 25);
            this.p_name.TabIndex = 1;
            // 
            // p_SSN
            // 
            this.p_SSN.Location = new System.Drawing.Point(482, 26);
            this.p_SSN.Name = "p_SSN";
            this.p_SSN.Size = new System.Drawing.Size(115, 25);
            this.p_SSN.TabIndex = 2;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.doctor_table);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1107, 592);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "醫生";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // doctor_table
            // 
            this.doctor_table.AllowUserToAddRows = false;
            this.doctor_table.AllowUserToDeleteRows = false;
            this.doctor_table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.doctor_table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewButtonColumn1});
            this.doctor_table.Location = new System.Drawing.Point(22, 260);
            this.doctor_table.Name = "doctor_table";
            this.doctor_table.ReadOnly = true;
            this.doctor_table.RowHeadersVisible = false;
            this.doctor_table.RowTemplate.Height = 27;
            this.doctor_table.Size = new System.Drawing.Size(1069, 313);
            this.doctor_table.TabIndex = 11;
            this.doctor_table.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.doctor_table_CellClick);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.d_dvname);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Controls.Add(this.d_sex);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.d_name);
            this.groupBox4.Controls.Add(this.d_SSN);
            this.groupBox4.Location = new System.Drawing.Point(22, 28);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1069, 95);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "新增醫生資料";
            // 
            // d_dvname
            // 
            this.d_dvname.Location = new System.Drawing.Point(482, 60);
            this.d_dvname.Name = "d_dvname";
            this.d_dvname.Size = new System.Drawing.Size(115, 25);
            this.d_dvname.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(306, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(130, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "所屬科別：";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(971, 26);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(92, 34);
            this.button4.TabIndex = 0;
            this.button4.Text = "新增";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // d_sex
            // 
            this.d_sex.Location = new System.Drawing.Point(103, 59);
            this.d_sex.Name = "d_sex";
            this.d_sex.Size = new System.Drawing.Size(40, 25);
            this.d_sex.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(306, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "身分證字號：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(18, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 24);
            this.label6.TabIndex = 4;
            this.label6.Text = "性別：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(18, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 24);
            this.label7.TabIndex = 3;
            this.label7.Text = "醫師名字：";
            // 
            // d_name
            // 
            this.d_name.Location = new System.Drawing.Point(160, 26);
            this.d_name.Name = "d_name";
            this.d_name.Size = new System.Drawing.Size(127, 25);
            this.d_name.TabIndex = 1;
            // 
            // d_SSN
            // 
            this.d_SSN.Location = new System.Drawing.Point(482, 26);
            this.d_SSN.Name = "d_SSN";
            this.d_SSN.Size = new System.Drawing.Size(115, 25);
            this.d_SSN.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.doctor_choose);
            this.groupBox3.Controls.Add(this.doctor_si);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Location = new System.Drawing.Point(22, 140);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1069, 100);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "查詢醫生資料";
            // 
            // doctor_choose
            // 
            this.doctor_choose.FormattingEnabled = true;
            this.doctor_choose.Items.AddRange(new object[] {
            "身分證字號",
            "性別",
            "醫師名字",
            "所屬科別"});
            this.doctor_choose.Location = new System.Drawing.Point(22, 43);
            this.doctor_choose.Name = "doctor_choose";
            this.doctor_choose.Size = new System.Drawing.Size(121, 23);
            this.doctor_choose.TabIndex = 2;
            this.doctor_choose.Text = "請選擇";
            // 
            // doctor_si
            // 
            this.doctor_si.Location = new System.Drawing.Point(160, 41);
            this.doctor_si.Name = "doctor_si";
            this.doctor_si.Size = new System.Drawing.Size(784, 25);
            this.doctor_si.TabIndex = 1;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(971, 41);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(92, 32);
            this.button3.TabIndex = 0;
            this.button3.Text = "查詢";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.division_table);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1107, 592);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "科別";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.division_choose);
            this.groupBox2.Controls.Add(this.division_si);
            this.groupBox2.Controls.Add(this.division_search);
            this.groupBox2.Location = new System.Drawing.Point(20, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1069, 100);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "查詢科別";
            // 
            // division_choose
            // 
            this.division_choose.FormattingEnabled = true;
            this.division_choose.Items.AddRange(new object[] {
            "科別編號",
            "科別名稱",
            "科別位置",
            "負責人"});
            this.division_choose.Location = new System.Drawing.Point(22, 43);
            this.division_choose.Name = "division_choose";
            this.division_choose.Size = new System.Drawing.Size(121, 23);
            this.division_choose.TabIndex = 2;
            this.division_choose.Text = "請選擇";
            // 
            // division_si
            // 
            this.division_si.Location = new System.Drawing.Point(160, 41);
            this.division_si.Name = "division_si";
            this.division_si.Size = new System.Drawing.Size(784, 25);
            this.division_si.TabIndex = 1;
            // 
            // division_search
            // 
            this.division_search.Location = new System.Drawing.Point(971, 41);
            this.division_search.Name = "division_search";
            this.division_search.Size = new System.Drawing.Size(92, 32);
            this.division_search.TabIndex = 0;
            this.division_search.Text = "查詢";
            this.division_search.UseVisualStyleBackColor = true;
            this.division_search.Click += new System.EventHandler(this.division_search_Click);
            // 
            // division_table
            // 
            this.division_table.AllowUserToAddRows = false;
            this.division_table.AllowUserToDeleteRows = false;
            this.division_table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.division_table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.division_table.Location = new System.Drawing.Point(20, 155);
            this.division_table.Name = "division_table";
            this.division_table.ReadOnly = true;
            this.division_table.RowHeadersVisible = false;
            this.division_table.RowTemplate.Height = 27;
            this.division_table.Size = new System.Drawing.Size(1069, 422);
            this.division_table.TabIndex = 7;
            this.division_table.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.division_table_CellClick);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.query_result);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.query_input);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1107, 592);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "首頁";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // query_result
            // 
            this.query_result.AllowUserToAddRows = false;
            this.query_result.AllowUserToDeleteRows = false;
            this.query_result.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.query_result.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.query_result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.query_result.Location = new System.Drawing.Point(29, 311);
            this.query_result.Name = "query_result";
            this.query_result.ReadOnly = true;
            this.query_result.RowHeadersVisible = false;
            this.query_result.RowTemplate.Height = 27;
            this.query_result.Size = new System.Drawing.Size(1069, 275);
            this.query_result.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(29, 243);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(1046, 48);
            this.button1.TabIndex = 3;
            this.button1.Text = "查詢";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "查詢 (Query)";
            // 
            // query_input
            // 
            this.query_input.Location = new System.Drawing.Point(29, 58);
            this.query_input.Name = "query_input";
            this.query_input.Size = new System.Drawing.Size(1046, 164);
            this.query_input.TabIndex = 1;
            this.query_input.Text = "";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1115, 621);
            this.tabControl1.TabIndex = 5;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox19);
            this.tabPage6.Controls.Add(this.groupBox18);
            this.tabPage6.Controls.Add(this.groupBox17);
            this.tabPage6.Controls.Add(this.groupBox16);
            this.tabPage6.Controls.Add(this.groupBox15);
            this.tabPage6.Controls.Add(this.groupBox14);
            this.tabPage6.Controls.Add(this.groupBox12);
            this.tabPage6.Controls.Add(this.groupBox11);
            this.tabPage6.Controls.Add(this.groupBox7);
            this.tabPage6.Controls.Add(this.search_result);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1107, 592);
            this.tabPage6.TabIndex = 7;
            this.tabPage6.Text = "進階查詢";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.label29);
            this.groupBox19.Controls.Add(this.button21);
            this.groupBox19.Controls.Add(this.label30);
            this.groupBox19.Controls.Add(this.doctor_n);
            this.groupBox19.Location = new System.Drawing.Point(20, 14);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(428, 78);
            this.groupBox19.TabIndex = 19;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "查詢醫師所屬科別的設備與其價錢";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label29.Location = new System.Drawing.Point(306, 60);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(0, 24);
            this.label29.TabIndex = 7;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(310, 22);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(92, 34);
            this.button21.TabIndex = 0;
            this.button21.Text = "查詢";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label30.Location = new System.Drawing.Point(18, 26);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(130, 24);
            this.label30.TabIndex = 3;
            this.label30.Text = "醫師名稱：";
            // 
            // doctor_n
            // 
            this.doctor_n.Location = new System.Drawing.Point(160, 26);
            this.doctor_n.Name = "doctor_n";
            this.doctor_n.Size = new System.Drawing.Size(127, 25);
            this.doctor_n.TabIndex = 1;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label28);
            this.groupBox18.Controls.Add(this.button20);
            this.groupBox18.Location = new System.Drawing.Point(203, 107);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(148, 78);
            this.groupBox18.TabIndex = 21;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "查詢有醫療儀器的科別";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label28.Location = new System.Drawing.Point(306, 60);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(0, 24);
            this.label28.TabIndex = 7;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(50, 38);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(92, 34);
            this.button20.TabIndex = 0;
            this.button20.Text = "查詢";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.label27);
            this.groupBox17.Controls.Add(this.button19);
            this.groupBox17.Location = new System.Drawing.Point(386, 107);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(148, 78);
            this.groupBox17.TabIndex = 20;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "查詢沒有醫療儀器的科別";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label27.Location = new System.Drawing.Point(306, 60);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(0, 24);
            this.label27.TabIndex = 7;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(50, 38);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(92, 34);
            this.button19.TabIndex = 0;
            this.button19.Text = "查詢";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label26);
            this.groupBox16.Controls.Add(this.button18);
            this.groupBox16.Location = new System.Drawing.Point(203, 200);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(148, 78);
            this.groupBox16.TabIndex = 19;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "查詢沒有管理科別的醫生";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label26.Location = new System.Drawing.Point(306, 60);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(0, 24);
            this.label26.TabIndex = 7;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(50, 38);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(92, 34);
            this.button18.TabIndex = 0;
            this.button18.Text = "查詢";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label24);
            this.groupBox15.Controls.Add(this.button17);
            this.groupBox15.Controls.Add(this.label25);
            this.groupBox15.Controls.Add(this.how_many);
            this.groupBox15.Location = new System.Drawing.Point(481, 14);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(428, 78);
            this.groupBox15.TabIndex = 18;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "查詢擁有超過?個病人的醫生";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label24.Location = new System.Drawing.Point(306, 60);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 24);
            this.label24.TabIndex = 7;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(310, 22);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(92, 34);
            this.button17.TabIndex = 0;
            this.button17.Text = "查詢";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label25.Location = new System.Drawing.Point(18, 26);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(130, 24);
            this.label25.TabIndex = 3;
            this.label25.Text = "病人數量：";
            // 
            // how_many
            // 
            this.how_many.Location = new System.Drawing.Point(160, 26);
            this.how_many.Name = "how_many";
            this.how_many.Size = new System.Drawing.Size(127, 25);
            this.how_many.TabIndex = 1;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button16);
            this.groupBox14.Controls.Add(this.label23);
            this.groupBox14.Location = new System.Drawing.Point(389, 200);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(148, 78);
            this.groupBox14.TabIndex = 21;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "查詢平均一位病患來醫院的次數";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(53, 38);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(92, 34);
            this.button16.TabIndex = 8;
            this.button16.Text = "查詢";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label23.Location = new System.Drawing.Point(306, 60);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 24);
            this.label23.TabIndex = 7;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button13);
            this.groupBox12.Controls.Add(this.label21);
            this.groupBox12.Controls.Add(this.button12);
            this.groupBox12.Location = new System.Drawing.Point(572, 200);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(241, 78);
            this.groupBox12.TabIndex = 19;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "查詢最貴/最便宜的設備";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(134, 38);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(92, 34);
            this.button13.TabIndex = 8;
            this.button13.Text = "MIN";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label21.Location = new System.Drawing.Point(306, 60);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(0, 24);
            this.label21.TabIndex = 7;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(22, 38);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(92, 34);
            this.button12.TabIndex = 0;
            this.button12.Text = "MAX";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label14);
            this.groupBox11.Controls.Add(this.button11);
            this.groupBox11.Location = new System.Drawing.Point(20, 107);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(152, 78);
            this.groupBox11.TabIndex = 18;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "查詢每位病患看診次數";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(306, 60);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 24);
            this.label14.TabIndex = 7;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(54, 38);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(92, 34);
            this.button11.TabIndex = 0;
            this.button11.Text = "查詢";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Controls.Add(this.button7);
            this.groupBox7.Location = new System.Drawing.Point(20, 200);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(152, 78);
            this.groupBox7.TabIndex = 17;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "查詢各科別擁有的設備價錢總金額";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(306, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 24);
            this.label15.TabIndex = 7;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(54, 38);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(92, 34);
            this.button7.TabIndex = 0;
            this.button7.Text = "查詢";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // search_result
            // 
            this.search_result.AllowUserToAddRows = false;
            this.search_result.AllowUserToDeleteRows = false;
            this.search_result.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.search_result.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.search_result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.search_result.Location = new System.Drawing.Point(20, 296);
            this.search_result.Name = "search_result";
            this.search_result.ReadOnly = true;
            this.search_result.RowHeadersVisible = false;
            this.search_result.RowTemplate.Height = 27;
            this.search_result.Size = new System.Drawing.Size(1069, 275);
            this.search_result.TabIndex = 9;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "科別編號";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "科別名稱";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "科別位置";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "負責人";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.HeaderText = "修改";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.HeaderText = "身分證字號";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.HeaderText = "性別";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.HeaderText = "醫師名字";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.HeaderText = "所屬科別";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewButtonColumn1.HeaderText = "修改";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.HeaderText = "身分證字號";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.HeaderText = "性別";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.HeaderText = "病患名字";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewButtonColumn3
            // 
            this.dataGridViewButtonColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewButtonColumn3.HeaderText = "修改";
            this.dataGridViewButtonColumn3.Name = "dataGridViewButtonColumn3";
            this.dataGridViewButtonColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.HeaderText = "病歷編號";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn11.HeaderText = "病患名字";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn10.HeaderText = "日期";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn12.HeaderText = "時間";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.HeaderText = "醫師姓名";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // dataGridViewButtonColumn6
            // 
            this.dataGridViewButtonColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewButtonColumn6.HeaderText = "刪除";
            this.dataGridViewButtonColumn6.Name = "dataGridViewButtonColumn6";
            this.dataGridViewButtonColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.HeaderText = "器材編號";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn14.HeaderText = "器材名稱";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn15.HeaderText = "價錢";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn16.HeaderText = "所屬科別";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            // 
            // dataGridViewButtonColumn8
            // 
            this.dataGridViewButtonColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewButtonColumn8.HeaderText = "刪除";
            this.dataGridViewButtonColumn8.Name = "dataGridViewButtonColumn8";
            this.dataGridViewButtonColumn8.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1139, 645);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabPage5.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.equipment_table)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.record_table)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.patient_table)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.doctor_table)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.division_table)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.query_result)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.search_result)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox e_dvno;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox e_name;
        private System.Windows.Forms.TextBox e_price;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ComboBox equipment_choose;
        private System.Windows.Forms.TextBox equipment_si;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.DataGridView equipment_table;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView record_table;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox record_choose;
        private System.Windows.Forms.TextBox record_si;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView patient_table;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox patient_choose;
        private System.Windows.Forms.TextBox patient_si;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox p_sex;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label p_sex1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox p_name;
        private System.Windows.Forms.TextBox p_SSN;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView doctor_table;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox d_dvname;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox d_sex;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox d_name;
        private System.Windows.Forms.TextBox d_SSN;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox doctor_choose;
        private System.Windows.Forms.TextBox doctor_si;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox division_choose;
        private System.Windows.Forms.TextBox division_si;
        private System.Windows.Forms.Button division_search;
        private System.Windows.Forms.DataGridView division_table;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView query_result;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox query_input;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView search_result;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox doctor_n;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox how_many;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewButtonColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn8;
    }
}

