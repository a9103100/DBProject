﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProject
{
    public partial class Form4 : Form
    {
        public Form4(String PSSN,String sex,String PName)
        {
            InitializeComponent();

            button2.DialogResult = System.Windows.Forms.DialogResult.OK;//設定button1為OK
            button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;//設定button為Cancel

            label4.Text = PSSN;
            textBox2.Text = sex;
            textBox3.Text = PName;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("欄位不得為空");
            }
            else
            {
                Form1 f1 = new Form1();
                string sql = "UPDATE patient SET sex='" + textBox2.Text + "',PName='" + textBox3.Text + "' WHERE PSSN='" + label4.Text + "'";
                MySqlCommand cmd = new MySqlCommand(sql, f1.conn);
                cmd.ExecuteNonQuery();
            }
        }

    }
}
