﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProject
{
    public partial class Form3 : Form
    {
        public Form3(String DSSN,String sex,String name,String DVName)
        {
            InitializeComponent();

            button2.DialogResult = System.Windows.Forms.DialogResult.OK;//設定button1為OK
            button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;//設定button為Cancel

            label5.Text = DSSN;
            textBox2.Text = sex;
            textBox3.Text = name;
            textBox4.Text = DVName;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox4.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("欄位不得為空");
                button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            }
            else
            {
                Form1 f1 = new Form1();
                string sql = "UPDATE doctor SET sex='" + textBox2.Text + "',name='" + textBox3.Text + "' WHERE DSSN='" + label5.Text + "'";
                MySqlCommand cmd = new MySqlCommand(sql, f1.conn);
                cmd.ExecuteNonQuery();

                string sql2 = "SELECT DVNo FROM division WHERE DVName='" + textBox4.Text + "'";
                MySqlCommand cmd2 = new MySqlCommand(sql2, f1.conn);
                string _DVNo="";
                int num = 0;
                if (cmd2.ExecuteScalar()==null)  //找不到資料
                {
                    _DVNo = (String)cmd2.ExecuteScalar();
                }
                else  //找出科別編號
                {
                    num = (int)cmd2.ExecuteScalar();
                }

                if (_DVNo==null)    //找不到資料，不修改所屬科別
                {
                    MessageBox.Show("無此科別");
                }
                else  
                {
                    string sql3 = "UPDATE doctor_division SET DVNo=" + num + " WHERE DSSN='" + label5.Text + "'";
                    MySqlCommand cmd3 = new MySqlCommand(sql3, f1.conn);
                    cmd3.ExecuteNonQuery();
                }
                
            }
        }
    }
}
